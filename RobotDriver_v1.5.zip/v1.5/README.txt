# Low-Cost-Roboterarm
A project for school classes concerning several engineering questions. Suitable from grade 10 upwards.

For further explanations, read the documentation or visit 
https://www.ife.uni-stuttgart.de/bpt/Mint-Teacher-Lab/Downloads.html for access to the thesis project concerning this topic.